namespace Wumpus_Test
{
    public partial class Form1 : Form
    {
        private GameLocation _gamelocation;
        public Form1()
        {
            InitializeComponent();
        }

        private void ConstuctorButton_Click(object sender, EventArgs e)
        {
            _gamelocation = new GameLocation();
        }
    }
}
