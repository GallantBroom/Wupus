﻿namespace Wumpus_Test
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ConstuctorButton = new Button();
            SuspendLayout();
            // 
            // ConstuctorButton
            // 
            ConstuctorButton.Location = new Point(256, 200);
            ConstuctorButton.Name = "ConstuctorButton";
            ConstuctorButton.Size = new Size(182, 87);
            ConstuctorButton.TabIndex = 0;
            ConstuctorButton.Text = "Constructor Button";
            ConstuctorButton.UseVisualStyleBackColor = true;
            ConstuctorButton.Click += ConstuctorButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(ConstuctorButton);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button ConstuctorButton;
    }
}
