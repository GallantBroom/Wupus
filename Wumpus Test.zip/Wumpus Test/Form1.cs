﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wumpus_Test
{

    public partial class Form1 : Form
    {
        private High_Score high_score;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonConstructor_Click(object sender, EventArgs e)
        {
            high_score = new High_Score();
        }
    }
}
