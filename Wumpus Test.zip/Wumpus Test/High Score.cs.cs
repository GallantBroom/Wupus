﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wumpus_Test
{
    internal class High_Score
    {
        public High_Score()
        {

        }
    }
}
